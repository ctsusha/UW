
//Implemented for future purpose
export class expag {
    name:string;
    id: number;
    startdate: string;
    description: string;
}