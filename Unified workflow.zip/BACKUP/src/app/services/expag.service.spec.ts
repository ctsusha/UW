import { TestBed, inject } from '@angular/core/testing';

import { ExpagService } from './expag.service';

describe('ExpagService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ExpagService]
    });
  });

  it('should be created', inject([ExpagService], (service: ExpagService) => {
    expect(service).toBeTruthy();
  }));
});
