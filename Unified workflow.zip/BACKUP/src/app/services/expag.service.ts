import { Injectable } from '@angular/core';
import { expag } from '../model/expag.model';

@Injectable()
export class ExpagService {
  // expag: expag[];
  temp: any;
  name:string;
  id: number;
  startdate: string;
  description: string;
  public expag = new expag();
  constructor(
  //  this.initexpag();
  ) { }

  // initexpag() {
  //   public expag = new expag();
  // }
  getExpag() {
    // return expag;
    this.temp = {'name':this.name, 'id':this.id, 'startdate': this.startdate, 'description': this.description };
    return this.temp;
  }

  setExpag(expag: expag) {
    // this.expag.push(expag);
    this.temp=JSON.stringify(expag);
  }

}
