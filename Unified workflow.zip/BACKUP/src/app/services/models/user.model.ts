export class User {
  id: number;
  email: string;
  user_token: string;
  name: string;
  password: string;
}
