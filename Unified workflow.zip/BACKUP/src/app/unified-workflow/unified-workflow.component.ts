import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list';
import { SampleFormComponent } from '../sample-form/sample-form.component';

import { ExpagService } from '../services/expag.service';
import { expag } from '../model/expag.model';

@Component({
  selector: 'app-unified-workflow',
  templateUrl: './unified-workflow.component.html',
  styleUrls: ['./unified-workflow.component.scss']
})
export class UnifiedWorkflowComponent implements OnInit {
  showForm: boolean = true;s
  router: Router;

  tiles = [
    1,'One','Sasi','Sample desc',
    2,'two','Trunks','Sample desc 2',
    3,'three','Goku','Sample desc 3',
    4,'four','Vegeta', 'Sample desc 4'
  ];

  constructor( ) { }

  ngOnInit() {

  }


  showReqDetailhere() {
    this.showForm = this.showForm ? false:true;
  }

  showReqDetail() {
    this.router.navigate(['/sampleForm']);
  }

  setExpagData() {
    // this.expagService.setExpag(this.expag);
  }

  getExpagData() {
    // console.log(this.expagService.getExpag());
  }
}