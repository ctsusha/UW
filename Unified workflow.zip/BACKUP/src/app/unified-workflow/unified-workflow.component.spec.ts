import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnifiedWorkflowComponent } from './unified-workflow.component';

describe('UnifiedWorkflowComponent', () => {
  let component: UnifiedWorkflowComponent;
  let fixture: ComponentFixture<UnifiedWorkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnifiedWorkflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnifiedWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
