import { ModuleWithProviders, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//Material components
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list'
// import { MatTableDataSource } from '@angular/material';
//CDK component
// import { DataSource } from '@angular/cdk/collections';
//User defined components
import { AppComponent } from './app.component';
import { AuthModule } from './modules/auth/auth.module';
import { HomeModule } from './modules/home/home.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';

import { ExpagService } from './services/expag.service';
import { expag } from './model/expag.model';

import {
  FooterComponent,
  HeaderComponent,
  SharedModule
}  from './shared';

import {
  ApiService,
  AuthGuard,
  JwtService,
  UserService,
} from './services';
import { UnifiedWorkflowComponent } from './unified-workflow/unified-workflow.component';
import { SampleFormComponent } from './sample-form/sample-form.component';

const rootRouting: ModuleWithProviders = RouterModule.forRoot([], { useHash: true });
const approutes: Routes = [
  { path:'', redirectTo:'/unified', pathMatch: 'full' },
  { path:'unified', component:UnifiedWorkflowComponent },
  { path:'sampleForm', component:SampleFormComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    UnifiedWorkflowComponent,
    SampleFormComponent
  ],
  imports: [
    BrowserModule,
    rootRouting,
	AuthModule,
    HomeModule,
	DashboardModule,
    SharedModule,
    MatGridListModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(approutes),
    MatTabsModule,
    MatExpansionModule,
    MatTableModule,
  ],
  providers: [
    ApiService,
    AuthGuard,
    JwtService,
    UserService,
    ExpagService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
